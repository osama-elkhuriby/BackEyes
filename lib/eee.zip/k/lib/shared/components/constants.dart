 import '../network/local_network.dart';

String? token = CacheNetwork.getCacheData(key: 'token');