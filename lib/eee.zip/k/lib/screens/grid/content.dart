class Contents {
  String image;
  String text;
// int index=0;
  Contents(this.image, this.text);
}

List<Contents> contentsa = [
  Contents('assets/home.png', 'Home Security'),
  Contents('assets/store.png', 'store'),
  Contents('assets/child.png', 'Child'),
  Contents('assets/others.png', 'Others'),
];
