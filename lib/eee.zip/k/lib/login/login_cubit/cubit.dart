import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart';
import 'package:http/http.dart'as http;
import 'package:prop/login/login_cubit/states.dart';

import '../../services/users.dart';

class LoginCubit extends Cubit<LoginStates>{
  LoginCubit() : super(LoginInitialState());
  static LoginCubit get(context) => BlocProvider.of(context);
  UserData ? model;
  bool val = false;
  void login({required String email,required String password}) async {
    emit(LoginLoadingState());
    try {
      //request =>url=base url + method url
      Response response = await http.post(
          Uri.parse('http://10.0.2.2/BackEyes_v2/public/api/login'),
          body: {
            'email': email,
            'password': password
          });
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        model = UserData.fromJson(data);
        print(data);
        emit(LoginSuccessState
          (model!.user!.apiToken!)
        );
        print(model?.message);
        print(model?.status);

      }
    }
    catch (e) {
      print(e);
      emit(FailedToLoginState(message: e.toString()));
    }
  }
    changebox(bool val1) {
      val = val1;
      print(val);
      emit(ChangeChexBoxLoginState());
    }
  }

