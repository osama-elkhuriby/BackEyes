import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:http/http.dart';
import 'package:http/http.dart' as http;
import 'package:prop/Register/Auth_cubit/states.dart';

import '../../services/users.dart';

class AuthCubit extends Cubit<AuthStates> {
  AuthCubit() : super(AuthInitialState());

  bool val = false;
  UserData ? model;
//Api url = http://localhost/BackEyes_v2/public/api/
//  Register endpoint=register
//  register http
  void register(
      {required String name,
      required String email,
      required String password}) async {
    emit(RegisterLoadingState());
    //word (register is endpoint)

    try{
      Response response = await http.post(
          Uri.parse("http://10.0.2.2/BackEyes_v2/public/api/register"),
          body: {
            "name": name,
            "email": email,
            "password": password,
          });
      var responseBody = jsonDecode(response.body);
      model = UserData.fromJson(responseBody);
      print(responseBody);
      emit(RegisterSuccessState
        (model!.user!.apiToken!)
      );
    }catch(e){
      print('===================================================');
      print(e.toString());
      emit(FailedToRegisterState(message: e.toString()));
    }
  }

  changebox(bool val1) {
    val = val1;
    print(val);
    emit(ChangeChexBoxRegisterState());
  }
}
