
import 'dart:async';
import 'dart:convert';

import 'package:bloc/bloc.dart';
import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:http/http.dart';
import 'package:http/http.dart'as http;
import 'package:prop/For_get/forget_cubit/states.dart';
class ForgetCubit extends Cubit<ForgetStates> {

  ForgetCubit() : super(ForgetInitialState());
  Future forget({required String email})async {
    emit(ForgetLoadingState());
    //word (forget-password is endpoint)
    Response response = await http.post(
        Uri.parse("http://10.0.2.2/BackEyes_v2/public/api/forget-password"),
        body: {
          "email": email,
        }
    );
    // var link =json.decode(response.body);
    // print(link);
    try{
    if (response.statusCode == 200) {
      var data = jsonDecode(response.body);
      if (data['status'] == true) {
        debugPrint("User login success and his Data is : $data");
        emit(ForgetSuccessState());
      }
      else {
        debugPrint("Failed to login ,reason is  : ${data['message']}");
        emit(FailedToForgetState(message: data['message']));
    }}}
  catch (e) {
  emit(FailedToForgetState(message: e.toString()));
  }}


 static ForgetCubit get (BuildContext context)=>BlocProvider.of(context);

   int? userId;
  String? token;
  Future sendCode({required String email,required String code})async {
    emit(SendCodeLoadingState());
    //word (forget-password is endpoint)
    Response response = await http.post(
        Uri.parse("http://10.0.2.2/BackEyes_v2/public/api/verify-code-reset-password"),
        body: {
          "email": email,
          "code": code,
        }
    );

    try{
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == true) {
          debugPrint("Send Code success and his Data is : $data");
          userId = data['data']['user_id'];
          token = data['data']['token'];
          print(userId);
          print(token);
          print('======================================');
          emit(SendCodeSuccessState());
        }
        else {
          debugPrint("Failed to login ,reason is  : ${data['message']}");
          emit(SendCodeFailedState(message: data['message']));
          print(data['message']);
        }}}
    catch (e) {
      emit(SendCodeFailedState(message: e.toString()));
      print(e.toString());
    }}

  Future changePassword({required String password})async {
    emit(ChangePasswordLoadingState());
    //word (forget-password is endpoint)
    Response response = await http.post(
        Uri.parse("http://10.0.2.2/BackEyes_v2/public/api/reset-password"),
        body: {
          "user_id": userId.toString(),
          "token": token,
          "password": password,
        }
    );

    try{
      if (response.statusCode == 200) {
        var data = jsonDecode(response.body);
        if (data['status'] == true) {
          debugPrint("Send Code success and his Data is : $data");
          emit(ChangePasswordSuccessState());
        }
        else {
          debugPrint("Failed to login ,reason is  : ${data['message']}");
          emit(ChangePasswordFailedState(message: data['message']));
          print(data['message']);
        }}}
    catch (e) {
      emit(ChangePasswordFailedState(message: e.toString()));
      print(e.toString());
    }}

  int seconds=0 ;
  bool isTimerRunning = false;
  Timer? timer;

  void startTimer(){
    seconds=60;
    isTimerRunning =true;
    timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      if (seconds==0){
        stopTimer();
      }else{
        seconds--;
      }
      emit(ResendCodeState());
    });
  }

  void stopTimer(){
    timer!.cancel();
    isTimerRunning =false;
  }

}






