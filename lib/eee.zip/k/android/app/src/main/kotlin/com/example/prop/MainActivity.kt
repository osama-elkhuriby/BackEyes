package com.example.prop

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
